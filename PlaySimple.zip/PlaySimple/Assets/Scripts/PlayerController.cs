﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class PlayerController : MonoBehaviour 
{
	public int speedFactor = 1000;
	float sensitivity = 7.5f;
	Vector3 mousePosition;

	public UnityAction onColideWithWall;



	void Update ()
	{
		#if UNITY_EDITOR
			if (Input.GetMouseButtonDown (0)) {
				mousePosition = Input.mousePosition;
			}
			if (Input.GetMouseButton (0)) {
				Vector3 mPosition = Input.mousePosition - mousePosition;
				if (mPosition.x > 0)
				transform.position += Vector3.right * Mathf.Lerp (0, sensitivity, Time.deltaTime * speedFactor); 
				if (mPosition.x < 0)
				transform.position += Vector3.left * Mathf.Lerp (0, sensitivity, Time.deltaTime * speedFactor); 
			}
		#else
			if (Input.touchCount > 0) {
				Vector2 mPosition = Input.GetTouch (0).deltaPosition;
				if (mPosition.x > 0)
					transform.position += Vector3.right * Mathf.Lerp (0, sensitivity, Time.deltaTime * speedFactor); 
				if (mPosition.x < 0)
					transform.position += Vector3.left * Mathf.Lerp (0, sensitivity, Time.deltaTime * speedFactor); 
			}
		#endif
	}

	void OnCollisionEnter2D(Collision2D col)
	{
		//End Game when collides with Wall
		if (col.gameObject.CompareTag ("wall")) {
			if(onColideWithWall != null)
				onColideWithWall.Invoke ();
		}


	}
}

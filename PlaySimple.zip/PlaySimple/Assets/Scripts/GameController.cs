﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour {

	public Transform mainScreen, gameOverScreen, gameplayScreen;
	public List<Transform> walls = new List<Transform>();
	public Text gameScore, gameOverScore;
	public PlayerController player;
	public Transform initialWall;

	Transform prevWall;

	int wallHeight = 2500;
	int score = 0;

	public void StartGame()
	{
		reset ();
		ScreenControl (ScreenType.Play);
		generateInitialWalls ();
		InvokeRepeating ("scoreCounter", 0, 1);
	}

	public void Retry()
	{
		SceneManager.LoadScene (0);
	}


	public void GameOver()
	{
		CancelInvoke ();
		ScreenControl (ScreenType.GameOver);
		gameOverScore.text = score.ToString();
	}

	void ScreenControl(ScreenType type)
	{
		mainScreen.gameObject.SetActive (type == ScreenType.Main);
		gameplayScreen.gameObject.SetActive (type == ScreenType.Play);
		gameOverScreen.gameObject.SetActive (type == ScreenType.GameOver);
	}

	public void generateInitialWalls()
	{
		initialWall.localPosition = new Vector3(0, 0, 0);
		initialWall.gameObject.SetActive (true);


		player.onColideWithWall += (delegate() {
			GameOver();
		});
		
		initialWall.GetComponent<MovementController>().onMovementFinish += (delegate {
			generateWalls ();
		});

		generateWalls ();
	}

	void reset()
	{
		score = 0;
		gameScore.text = "0";
		foreach (Transform t in walls)
			t.gameObject.SetActive (false);
	}

	public void generateWalls()
	{
		int count = walls.Count;

		if (count != 0) {

			int i = Random.Range (0, count);
			Transform t = walls [i];
			t.gameObject.SetActive (true);



			if (prevWall != null) 
				t.transform.localPosition = new Vector3 (0f, prevWall.transform.localPosition.y + wallHeight, 0f);
			else
				t.transform.localPosition = new Vector3 (0f, wallHeight, 0f);

			prevWall = t;

			MovementController mController = t.GetComponent<MovementController> ();
			mController.StartMovement ();

			mController.onMovementFinish = null;
			mController.onMovementFinish += (delegate {
				walls.Add(t);
				generateWalls ();
			});

			walls.RemoveAt (i);

		} else {
			Debug.Log ("Add atleast two walls");
		}
	}


	void scoreCounter()
	{
		score += 1;
		gameScore.text = score.ToString();
	}
}

public enum ScreenType
{
	Main,
	Play,
	GameOver
}

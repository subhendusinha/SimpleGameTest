﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class MovementController : MonoBehaviour 
{
	float speedFactor = 1000;

	public UnityAction onMovementFinish;

	void Start()
	{
		StartMovement ();
	}

	public void StartMovement()
	{
		StopAllCoroutines ();
		StartCoroutine (move ());
	}

	public void StopMovement()
	{
		StopAllCoroutines ();
	}

	IEnumerator move()
	{
		while (true) {
			transform.position += Vector3.down * Mathf.Lerp (0, 10, Time.deltaTime * speedFactor); 
			yield return null;
		}
	}

	void OnTriggerExit2D(Collider2D col)
	{
		if (col.tag.CompareTo ("Repeater") == 0) {
			StopMovement ();
//
//			if (this.transform.CompareTag ("Starter"))
//				Destroy (this.gameObject);
//			else 
				gameObject.SetActive (false);

			if (onMovementFinish != null) {
				onMovementFinish.Invoke ();
			}
		}
	}

}
